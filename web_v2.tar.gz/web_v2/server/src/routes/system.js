import { Router } from 'express';
import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';

const router = Router();
const HESTIA_DIR = process.env.HESTIA || '/usr/local/hestia';

/**
 * GET /api/system/info
 * Get system configuration info (shells, php versions, packages)
 */
router.get('/info', async (req, res) => {
  try {
    // Get available shells
    let shells = ['/bin/bash', '/bin/sh', '/usr/sbin/nologin'];
    try {
      const shellsData = fs.readFileSync('/etc/shells', 'utf8');
      shells = shellsData.split('\n')
        .map(s => s.trim())
        .filter(s => s && !s.startsWith('#'));
    } catch (e) {
      // Use defaults
    }

    // Get PHP versions
    let phpVersions = [];
    try {
      const phpDir = '/etc/php';
      if (fs.existsSync(phpDir)) {
        phpVersions = fs.readdirSync(phpDir)
          .filter(f => /^\d+\.\d+$/.test(f))
          .map(v => `php${v}`)
          .sort();
      }
    } catch (e) {
      // No PHP versions found
    }

    // Get packages
    let packages = ['default'];
    try {
      const packagesDir = path.join(HESTIA_DIR, 'data/packages');
      if (fs.existsSync(packagesDir)) {
        packages = fs.readdirSync(packagesDir)
          .filter(f => f.endsWith('.pkg'))
          .map(f => f.replace('.pkg', ''));
      }
    } catch (e) {
      // Use defaults
    }

    // Get languages
    const languages = [
      { code: 'en', name: 'English' },
      { code: 'vi', name: 'Tiếng Việt' },
      { code: 'de', name: 'Deutsch' },
      { code: 'fr', name: 'Français' },
      { code: 'es', name: 'Español' },
      { code: 'ru', name: 'Русский' },
      { code: 'zh-cn', name: '中文 (简体)' },
      { code: 'ja', name: '日本語' },
      { code: 'pt-br', name: 'Português (BR)' },
      { code: 'nl', name: 'Nederlands' },
      { code: 'pl', name: 'Polski' },
      { code: 'it', name: 'Italiano' }
    ];

    res.json({
      shells,
      phpVersions,
      packages,
      languages
    });
  } catch (error) {
    console.error('System info error:', error);
    res.status(500).json({ error: 'Failed to get system info' });
  }
});

export default router;
